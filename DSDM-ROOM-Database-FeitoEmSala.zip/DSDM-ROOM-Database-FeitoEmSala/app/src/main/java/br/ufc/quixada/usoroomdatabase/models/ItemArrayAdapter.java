package br.ufc.quixada.usoroomdatabase.models;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import br.ufc.quixada.usoroomdatabase.R;

public class ItemArrayAdapter extends RecyclerView.Adapter<ItemArrayAdapter.ViewHolder> {

    private final int listItemLayout;
    private final ArrayList<Pessoa> itemList;

    public ItemArrayAdapter(int layoutId, ArrayList<Pessoa>itemList){
        listItemLayout = layoutId;
        this.itemList = itemList;
    }

    @Override
    public int getItemCount(){
        return itemList == null ? 0 : itemList.size();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(listItemLayout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int listPosition){
        TextView item_nome = holder.item_nome;
        item_nome.setText(itemList.get(listPosition).getNome());

        TextView item_curso = holder.item_curso;
        item_curso.setText(itemList.get(listPosition).getCurso());

        TextView item_idade = holder.item_idade;
        item_idade.setText(String.valueOf(itemList.get(listPosition).getIdade()));
    }

    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        public TextView item_nome;
        public TextView item_curso;
        public TextView item_idade;
        public ViewHolder(View itemView){
            super(itemView);
            itemView.setOnClickListener(this);
            item_nome = itemView.findViewById(R.id.nome_tv);
            item_curso =  itemView.findViewById(R.id.curso_tv);
            item_idade =  itemView.findViewById(R.id.idade_tv);
        }

        @Override
        public void onClick(View v) {
            Toast.makeText(itemView.getContext(),"Você clicou na pessoa "+ item_nome.getText(),Toast.LENGTH_SHORT).show();
        }

    }
}
