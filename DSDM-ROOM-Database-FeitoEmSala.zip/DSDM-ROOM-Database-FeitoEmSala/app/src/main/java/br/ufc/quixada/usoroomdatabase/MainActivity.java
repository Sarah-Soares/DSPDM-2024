package br.ufc.quixada.usoroomdatabase;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import br.ufc.quixada.usoroomdatabase.dao.PessoaDao;
import br.ufc.quixada.usoroomdatabase.database.AppDatabase;
import br.ufc.quixada.usoroomdatabase.models.ItemArrayAdapter;
import br.ufc.quixada.usoroomdatabase.models.Pessoa;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        AppDatabase appDatabase = Room.databaseBuilder(this,
                AppDatabase.class,
                "db_pessoas")
                .enableMultiInstanceInvalidation()
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        PessoaDao pessoaDao = appDatabase.pessoaDao();
        List<Pessoa> pessoasDoBd = pessoaDao.getAllPessoas();
        for(Pessoa p : pessoasDoBd){
            Log.d("sid-tag", p.toString());
        }

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        ItemArrayAdapter adapter = new ItemArrayAdapter(R.layout.pessoa_fragment,(ArrayList<Pessoa>)pessoasDoBd);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        FloatingActionButton botaoAdicionar = findViewById(R.id.floatingActionButtonAdicionar);
        botaoAdicionar.setOnClickListener(v->{
            Intent intent = new Intent(this, ActivityAdicao.class);
            startActivity(intent);
        });
    }

    @Override
    public void onResume(){
        super.onResume();
        AppDatabase appDatabase = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "db_pessoas")
                .enableMultiInstanceInvalidation()
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        PessoaDao pessoaDao = appDatabase.pessoaDao();
        List<Pessoa> pessoasDoBd = pessoaDao.getAllPessoas();
        for(Pessoa p : pessoasDoBd){
            Log.d("sid-tag", p.toString());
        }

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        ItemArrayAdapter adapter = new ItemArrayAdapter(R.layout.pessoa_fragment,(ArrayList<Pessoa>)pessoasDoBd);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        FloatingActionButton botaoAdicionar = findViewById(R.id.floatingActionButtonAdicionar);
        botaoAdicionar.setOnClickListener(v->{
            Intent intent = new Intent(this, ActivityAdicao.class);
            startActivity(intent);
        });
    }
}