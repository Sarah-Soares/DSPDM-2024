package br.ufc.quixada.usoroomdatabase;

import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.room.Room;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import br.ufc.quixada.usoroomdatabase.database.AppDatabase;
import br.ufc.quixada.usoroomdatabase.models.Pessoa;

public class ActivityAdicao extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pessoa_adicao);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText nomeEditText = findViewById(R.id.nomeEditText);
        EditText idadeEditText = findViewById(R.id.idadeEditTextNumber);
        EditText cursoEditText = findViewById(R.id.cursoEditText);
        FloatingActionButton botaoCriar = findViewById(R.id.adicionarBotaoFlutuante);

        AppDatabase appDatabase = Room.databaseBuilder(this,
                        AppDatabase.class,
                        "db_pessoas")
                .enableMultiInstanceInvalidation()
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();
        botaoCriar.setOnClickListener(v->{
            try {
                String nome = nomeEditText.getText().toString();
                String curso = cursoEditText.getText().toString();
                int idade = Integer.parseInt(idadeEditText.getText().toString());
                Pessoa pessoaNova = new Pessoa(nome,curso,idade);
                appDatabase.pessoaDao().insertAll(pessoaNova);
                finish();
            }catch ( Exception e){
                Log.e("Erro Criando pessoa", "Erro ao criar pessoa no banco");
                finish();
            }

        });

    }
}